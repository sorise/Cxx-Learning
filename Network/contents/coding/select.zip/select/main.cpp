#include <netinet/in.h>

#include "must.h"
#include "socket_wrap.hpp"
#include <vector>
#include <list>
#include <algorithm>
#include <functional>
#include <worker.hpp>
#include <queue>
#include <shared_mutex>
#include <string>

void AcceptConnection(unsigned short port,int max, const bool &isRunning, std::vector<Package> &allPackages){
    auto fd = initServer(port, max);//初始化
    fd_set readSet, allSet;
    FD_ZERO(&allSet);
    FD_SET(fd, &allSet); //加入
    auto readyCount = 0;
    while (isRunning){
        timeval _timeout{2,0};
        readSet = allSet;
        readyCount = select(fd + 1, &readSet, nullptr, nullptr, &_timeout);
        //阻塞等待
        if (readyCount < 0){
            throw std::runtime_error("error happen in select function!"); //发生错误
        }
        if (readyCount == 0) continue;
        //新的连接
        if (FD_ISSET(fd, &readSet)){
            //有新的客户端连接
            sockaddr_in link_addr{};
            socklen_t len = sizeof(link_addr);
            auto newFd = Accept(fd, (struct sockaddr *)&link_addr, &len);
            std::cout << "new socket connection: " << newFd << " from port - " << ntohs(link_addr.sin_port)  << std::endl;
            Connection con { newFd,
                             ConnectionState::online,
                             link_addr,
                              0,
            };
            //将连接加入队列
            {
                //负载均衡
                int idx = 0;
                int count = allPackages[0].count;
                for (int i = 0; i < allPackages.size(); ++i) {
                    if (allPackages[i].count < count  ){
                        idx = i;
                    }
                }
                std::lock_guard<std::mutex> lock(allPackages[idx]._mutex);
                allPackages[idx].allConnection.push(con);
                allPackages[idx].condition.notify_one();
                allPackages[idx].count ++;
            }
        }
    }
}

int main() {
    bool isRun = true;
    std::vector<Package> allPackages(2);
    //工作线程负责处理读写任务
    std::thread worker_p1(Runner ,std::ref(allPackages[0]._mutex), std::ref(allPackages[0].allConnection),
                          std::ref(allPackages[0].condition), std::ref(allPackages[0].count), std::ref(isRun));

    std::thread worker_p2(Runner ,std::ref(allPackages[1]._mutex), std::ref(allPackages[1].allConnection),
                          std::ref(allPackages[1].condition), std::ref(allPackages[1].count), std::ref(isRun));


    std::thread listener(AcceptConnection, 15555, 20, std::ref(isRun), std::ref(allPackages));
    //用于结束
    while (true){
        char buffer[128];
        bzero(buffer, sizeof(char)*128);
        std::cin.getline(buffer, 127);
        std::string b(buffer);
        if (b.find('$') != std::string::npos){
            isRun = false;
            break;
        }
    }
    std::cout << "waiting end the progress ！ " << std::endl << std::flush;
    for(auto & p: allPackages){
        p.condition.notify_all();
    }
    std::cout << "worker thread has been notified ！ " << std::endl << std::flush;
    worker_p1.join();
    worker_p2.join();
    std::cout << "worker thread has been end! " << std::endl << std::flush;
    listener.join();
    return 0;
}
