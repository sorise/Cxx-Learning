//
// Created by remix on 23-4-22.
//

#ifndef SELECT_WORKER_HPP_
#define SELECT_WORKER_HPP_
#include <arpa/inet.h>
#include <queue>
#include "socket_wrap.hpp"

enum class ConnectionState {
    offline = 0,
    online = 1
};

struct Connection{
    int socketId;
    ConnectionState state; //连接状态
    sockaddr_in serverAddress;
    int writeCount;
};

struct Package{
    std::mutex _mutex;
    std::queue<Connection> allConnection; //加入
    int count {0}; //管理连接数量
    std::condition_variable condition;
};

void Runner(std::mutex& mtx, std::queue<Connection>& JoinConnection,std::condition_variable &_condition,
            int& count,  const bool &isRunning){
    std::list<Connection> CatchConnections; //持有的连接
    while (isRunning){
        //有新连接吗？ 有的加入
        if (!JoinConnection.empty()){
            //加入连接中
            std::lock_guard<std::mutex> lock(mtx);
            while (!JoinConnection.empty()){
                CatchConnections.push_back(JoinConnection.front());
                JoinConnection.pop();
            }
        }else{
            //没有新连接，而且自己也没有连接了，阻塞等待
            if (CatchConnections.empty()){
                std::unique_lock<std::mutex> lock(mtx);
                _condition.wait(lock, [&](){
                    return !JoinConnection.empty() || !isRunning;
                });
                if (!isRunning) return;
                while (!JoinConnection.empty()){
                    CatchConnections.push_back(JoinConnection.front());
                    JoinConnection.pop();
                }
                lock.unlock();
            }
        }
        //开始运行
        fd_set readSet, writeSet, allSet;
        FD_ZERO(&allSet);
        int maxSocketFd = CatchConnections.begin()->socketId;
        for (auto &con: CatchConnections) {
            if (con.socketId > maxSocketFd) maxSocketFd = con.socketId;
            FD_SET(con.socketId, &allSet);
        }
        readSet = allSet;
        writeSet = allSet;//问题 写事件基本处于满
        timeval timeout{ 1,0 };
        int readyCount = select(maxSocketFd + 1, &readSet, nullptr, nullptr, &timeout);
        if (readyCount < 0)  {
            throw std::runtime_error("error happen in select");
        }
        //读事件
        auto start = CatchConnections.begin();
        while (start != CatchConnections.end()){
            if (FD_ISSET(start->socketId , &readSet)){
                char buffer[4096]; //缓冲区
                auto read_count = recv(start->socketId, buffer, 4096, 0);
                if (read_count == 0) {
                    start->state = ConnectionState::offline;
                    close(start-> socketId); //关闭了
                    FD_CLR(start->socketId, &allSet);
                    std::cout << "the connect " << std::to_string(start->socketId) <<" has been end !" << std::endl;
                }
                if (read_count == -1){
                    if (errno == EINTR){
                        start--; //被中断 重新读取
                        continue;
                    }
                    if (errno == EBADF){
                        start->state = ConnectionState::offline;
                    }
                    throw std::runtime_error(std::to_string(start->socketId) + " read error! " + std::to_string(errno) ); //发生错误
                }
                buffer[read_count] = '\0';
                std::cout << "message: " << buffer << std::flush;
            }
            start++;
        }
        int remove_count = 0;
        CatchConnections.remove_if([&](auto &con){
            if (con.state == ConnectionState::offline){
                remove_count++;
                return true;
            }
            return false;
        });
        if (remove_count > 0){
            std::lock_guard<std::mutex> lock(mtx);
            count = CatchConnections.size();
        }
    }
}
#endif //SELECT_WORKER_HPP_
