//
// Created by remix on 23-4-25.
//

#ifndef EPOLL_WRAP_HPP
#define EPOLL_WRAP_HPP
#include <sys/epoll.h>
#include <iostream>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <shared_mutex>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <exception>

#define OPEN_MAX_CLIENT_CONNECTION 2048

namespace wrap{
    int Socket(int domain,int type,int protocol){
        auto socket_fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
        if (socket_fd == -1) {
            throw std::runtime_error("create the socket failed!");
        }
        return socket_fd;
    }

    int Bind(int socket_fd, const struct sockaddr *addr, socklen_t addrlen){
        auto result = bind(socket_fd, addr, addrlen);
        if (result == -1) {
            throw std::runtime_error("bind occur error, please check the data sockaddr!");
        }
        return result;
    }

    void Listen(int socket_fd, int backlog){
        auto result =  listen(socket_fd, backlog);
        if (result == -1) {
            throw std::runtime_error("listen occur error,the socket failed!");
        }
    }

    int Accept(int socket_fd, struct sockaddr *addr, socklen_t *addrlen){
        auto new_socket_fd = accept4(socket_fd, addr, addrlen, SOCK_NONBLOCK);
        if (new_socket_fd == -1) {
            throw std::runtime_error("accept occur error,the socket failed!");
        }
        return new_socket_fd;
    }

    int Close(int fd){
        auto result = close(fd);
        if (result == -1) {
            throw std::runtime_error("close the socket failed! - errno: "+ std::to_string(errno));
        }
        return result;
    }

    int initServer(unsigned short port, unsigned short max_connection){
        auto fd = Socket(AF_INET, SOCK_STREAM,0);
        /* 允许地址复用 */
        int opt = 1;
        if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt)) == -1){
            throw std::runtime_error("set socket error！");
        }
        /* 设置为非阻塞 */
        int newSocketFlag = fcntl(fd, F_GETFL, 0) | O_NONBLOCK;
        fcntl(fd,F_GETFL, newSocketFlag);
        /* 设置发送缓存低潮 */
        int sendLowBufferSize = 2048 ; //2k 字节
        setsockopt(fd, SOL_SOCKET, SO_SNDLOWAT, (const void *) &sendLowBufferSize, sizeof(sendLowBufferSize));
        /* 设置关闭前先发完 */
        linger m_sLinger{1,5};
        setsockopt( fd, SOL_SOCKET, SO_LINGER, (const char*)&m_sLinger, sizeof(struct linger));
        /* 服务器地址 */
        sockaddr_in serverAddress{
                AF_INET,
                htons(port),
                htonl(INADDR_ANY)
        };
        /* 绑定 */
        Bind(fd, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));
        /* 监听 */
        Listen(fd, max_connection);
        std::cout << "start server at 127.0.0.1 running in "<< std::to_string(port) <<":" << "\n";
        return fd; //返回套接字
    }



    auto Epoll_ctl(int _epfd, int _op, int _fd, struct epoll_event *_event) ->
    decltype(epoll_ctl(_epfd,_op,_fd, _event)){
        auto v = epoll_ctl(_epfd,_op,_fd, _event);
        if (v != 0){
            throw std::runtime_error(std::to_string(_fd) +
                                     ": error happen in Epoll_ctl ! errno: " + std::to_string(errno));
        }
        return v;
    }

    void createEpollServer(){
        auto server_fd = initServer(15000, 128);
        struct epoll_event temp{EPOLLIN | EPOLLERR}, epollQueue[OPEN_MAX_CLIENT_CONNECTION];
        struct epoll_event server_et{EPOLLIN | EPOLLERR, {.fd =  server_fd}};
        auto epollFd = epoll_create(1);
        if (epollFd == -1 ){
            throw std::runtime_error("error is happen! errno: " + std::to_string(errno));
        }
        Epoll_ctl(epollFd, EPOLL_CTL_ADD, server_fd, &server_et);

        bool running  = true;
        while (running){
            auto readyCount = epoll_wait(epollFd, epollQueue,
                                         OPEN_MAX_CLIENT_CONNECTION, -1);
            for (int i = 0; i < readyCount; ++i) {
                //非读事件
                if (epollQueue[i].events & EPOLLERR){
                    running = false; //有错误停止运行
                    break;
                }
                //有新连接
                if (epollQueue[i].data.fd == server_fd){
                    sockaddr_in address{};
                    socklen_t len;
                    auto clientFd = Accept(server_fd, (struct sockaddr *)&address, &len);
                    temp.data.fd = clientFd;
                    temp.events = EPOLLIN;
                    /* --- 受到新连接日志消息 --- */
                    char *addrIP = inet_ntoa(address.sin_addr);
                    std::cout << "new socket connection: " << clientFd << " from ip: "<< addrIP <<" port: "
                              << ntohs(address.sin_port)  << std::endl;
                    Epoll_ctl(epollFd, EPOLL_CTL_ADD, clientFd ,&temp);
                }
                else{
                    char buffer[4096]; //缓冲区
                    auto read_count = recv(epollQueue[i].data.fd, buffer, 4096, 0);
                    if (read_count == 0) {
                        std::cout << "the connect " << std::to_string(epollQueue[i].data.fd) <<" has been end !" << std::endl;
                        Epoll_ctl(epollFd, EPOLL_CTL_DEL, epollQueue[i].data.fd, nullptr); //删除
                        close(epollQueue[i].data.fd); //关闭了
                    }
                    if (read_count < 0){
                        if (errno == EINTR){
                            i--; //被中断 重新读取
                            continue;
                        }
                        //需要关闭
                        if (errno == ECONNRESET){
                            std::cout << "the connect " << std::to_string(epollQueue[i].data.fd) <<" has been end !" << std::endl;
                            Epoll_ctl(epollFd, EPOLL_CTL_DEL, epollQueue[i].data.fd, nullptr); //删除
                            close(epollQueue[i].data.fd); //关闭了
                        }
                        throw std::runtime_error(std::to_string(epollQueue[i].data.fd) +
                                                 " read error - errno: " + std::to_string(errno) ); //发生错误
                    }

                    if (read_count > 0 ){
                        buffer[read_count] = '\0';
                        std::cout << "from " << std::to_string(epollQueue[i].data.fd)   <<": " << buffer << std::flush;
                        std::string  message = "get bytes " + std::to_string(read_count) + "\n";
                        auto write_count = write(epollQueue[i].data.fd,
                                                 message.c_str() , sizeof(char)*message.size());
                        if (write_count <= 0){
                            throw std::runtime_error(std::to_string(epollQueue[i].data.fd) +
                                                     ": error happen in write ! errno: " + std::to_string(errno));
                        }
                    }
                }
            }
        }
    }
}

#endif //EPOLL_WRAP_HPP
