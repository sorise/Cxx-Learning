#include <iostream>
#include "net/wrap.hpp"
#include <chrono>

#ifndef  OPEN_MAX_CLIENT_CONNECTION
    #define OPEN_MAX_CLIENT_CONNECTION 2048
#endif

void clientReadCallBack(int fd, uint32_t event, void *arg);
void clientWriteCallBack(int fd, uint32_t event, void *arg);
void serverCallBack(int fd, uint32_t event, void *arg);

namespace epollSetting{
    int globEpollFd;
}
//希望用堆来存储，而不是栈，但是需要list来存储指针！
struct EventHandler {
    static const int BUFFER_LENGTH = 4096;
    int fd{0};                                                 //要监听的文件描述符
    uint32_t events{0};                                             //对应的监听事件
    void *arg{nullptr};                                              //泛型参数
    void (*callBack)(int fd, uint32_t events, void *arg){};       //回调函数
    bool status;                                             //是否在监听:1->在红黑树上(监听), 0->不在(不监听)
    char *buf{nullptr};
    unsigned long len{0};
    sockaddr_in address{};
    std::time_t last_active{0};                                       //记录每次加入红黑树 g_efd 的时间值
    EventHandler(int _fd, uint32_t _events, bool _status)
    :fd(_fd), events(_events),status(_status){}
};

//处理写事件 arg 就是 EventHandler*
void clientWriteCallBack(int fd, uint32_t event, void *arg){
    wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_DEL, fd, nullptr);
    auto handler = (EventHandler*)arg;
    auto write_count = send(fd ,handler->buf , handler->len,0);
    if (write_count <= 0){
        throw std::runtime_error(std::to_string(fd) +
                                 ": error happen in write ! errno: " + std::to_string(errno));
    }
    //挂回去
    free(handler->buf); //释放掉
    handler->len = 0;
    handler->buf = nullptr;
    handler->callBack = clientReadCallBack;
    auto monitor_event = EPOLLIN;
    handler->last_active = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    struct epoll_event temp{monitor_event, {.ptr = handler}};
    wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_ADD, fd, &temp);
}

//处理读事件 arg 就是 EventHandler*
void clientReadCallBack(int fd, uint32_t event, void *arg){
    auto handler = (EventHandler *)arg;
    char buffer[2049]; //缓冲区
    auto read_count = recv(fd, buffer, 2048, 0);
    if (read_count == 0) {
        std::cout << "the connect " << std::to_string(fd) <<" has been end !" << std::endl;
        close(fd); //关闭了
        delete handler;
        handler = nullptr;
    }
    if (read_count < 0){
        if (errno == EINTR){
            return;
        }
        //需要关闭
        if (errno == ECONNRESET){
            std::cout << "the connect " << std::to_string(fd)
                      <<" has been end !" << std::endl;
            delete handler;
            handler = nullptr;
            wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_DEL, fd , nullptr);
            close(fd); //关闭了
            return;
        }
        wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_DEL, fd , nullptr);
        throw std::runtime_error(std::to_string(fd) +
                                 " read error - errno: " + std::to_string(errno) ); //发生错误
    }
    if (read_count > 0 ){
        char *addrIP = inet_ntoa(handler->address.sin_addr);
        buffer[read_count] = '\0';
        std::cout << addrIP <<" - " << ntohs(handler->address.sin_port) << ": " << buffer << std::flush;
        std::string  message = "get bytes " + std::to_string(read_count) + "\n";
        char *sendData = new char[message.size() + 1];
        for (int i = 0; i < message.size(); ++i) {
            sendData[i] = message[i];
        }
        sendData[message.size()] = '\0';
        auto monitor_event = EPOLLOUT;
        auto clientWriteHandler = handler;
        handler->callBack = clientWriteCallBack;
        handler->len = message.size();
        handler->buf = sendData;
        handler->status = true;
        handler->last_active = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        struct epoll_event temp{monitor_event, {.ptr = clientWriteHandler}};
        wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_MOD, fd , &temp);
        //重新放回去
    }
}
//处理新到的客户端
void serverCallBack(int fd, uint32_t event, void *arg){
    auto monitor_event = EPOLLIN;
    sockaddr_in addr{};
    socklen_t len = sizeof(addr);;
    auto clientFd =  wrap::Accept(fd, (struct sockaddr*)&addr, &len);
    char *addrIP = inet_ntoa(addr.sin_addr);
    std::cout << "new socket connection: " << clientFd << " from ip: "<< addrIP <<" port: "
              << ntohs(addr.sin_port)  << std::endl;
    auto* clientHandler = new EventHandler(clientFd, monitor_event, false);
    struct epoll_event temp {monitor_event, {.ptr = clientHandler}};
    clientHandler->status = true;
    clientHandler->callBack = clientReadCallBack;
    clientHandler->address.sin_addr.s_addr = addr.sin_addr.s_addr;
    clientHandler->address.sin_port = addr.sin_port;
    clientHandler->last_active = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    wrap::Epoll_ctl(epollSetting::globEpollFd, EPOLL_CTL_ADD, clientFd ,&temp);
}

void createReactor(){
    auto serverSocketFd = wrap::initServer(15000, 128);
    auto epollFd = epoll_create(1);
    if (epollFd == -1 ){
        throw std::runtime_error("error is happen! errno: " + std::to_string(errno));
    }
    epollSetting::globEpollFd = epollFd;
    struct epoll_event epollQueue[OPEN_MAX_CLIENT_CONNECTION];

    EventHandler serverHandler(serverSocketFd, EPOLLIN|EPOLLERR, true);
    serverHandler.callBack = serverCallBack;
    struct epoll_event server_ev {EPOLLIN|EPOLLERR,{.ptr = &serverHandler}};
    wrap::Epoll_ctl(epollFd, EPOLL_CTL_ADD,serverSocketFd, &server_ev);
    bool running  = true;
    while (running){
        auto readyCount = epoll_wait(epollFd, epollQueue,
                                     OPEN_MAX_CLIENT_CONNECTION, -1);
        for (int i = 0; i < readyCount; ++i) {
            if (epollQueue[i].events & EPOLLERR){
                running = false; //有错误停止运行
                break;
            }
            auto handler = (EventHandler *)epollQueue[i].data.ptr;
            handler->callBack(handler->fd, epollQueue[i].events, handler);
        }
    }
}

int main() {
    createReactor();
    return 0;
}
