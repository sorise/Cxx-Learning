#include <iostream>
#include "wrap.hpp"
#include <poll.h>

int main() {
    const int MAX_CONNECTION = 1024;
    auto fd = initServer(15000, 40);
    struct pollfd fds[MAX_CONNECTION];

    fds[0] = { fd, POLLIN, 0 };
    for (int i = 1; i < 1024 ; i++) {
        fds[i].fd = -1;
        fds[i].events = POLLIN;
    }

    int max_index = 0;
    struct sockaddr_in client_addr {};

    while (true){
        int result = poll(fds, max_index + 1, -1);
        if (result == -1) throw std::runtime_error("error in poll! errno: " + std::to_string(errno));
        //来了新连接
        socklen_t len;
        if (fds[0].revents & POLLIN){
            auto clientFd = Accept(fds[0].fd, (struct sockaddr *)&client_addr, &len);
            char *addrIP = inet_ntoa(client_addr.sin_addr);
            std::cout << "new socket connection: " << clientFd << " from ip: "<< addrIP <<" port: "
                << ntohs(client_addr.sin_port)  << std::endl;

            int j = 1;
            //看看有没有空闲位置
            for (; j <= max_index; j++) {
                if (fds[j].fd < 0) {
                    fds[j].fd = clientFd;
                }
            }
            if (max_index + 1 == MAX_CONNECTION) {
                std::string message{"the server is overload! please try after a while!"};
                send(clientFd, message.c_str(), sizeof(char) * message.size(),0);
            }
            //没有空闲，则增加
            if (j == max_index + 1){
                max_index++;
                fds[max_index].fd = clientFd;
            }
        }

        //处理客户端读
        for (int i = 1; i <= max_index; ++i) {
            if (fds[i].fd != -1 && (fds[i].revents & POLLIN)){
                char buffer[4096]; //缓冲区
                auto read_count = recv(fds[i].fd, buffer, 4096, 0);
                if (read_count == 0) {
                    std::cout << "the connect " << std::to_string(fds[i].fd) <<" has been end !" << std::endl;
                    close(fds[i].fd); //关闭了
                    fds[i].fd = -1; //取消了

                    //降低上限
                    if (i == max_index){
                        while (max_index >= 1 && fds[max_index].fd < 0)
                            max_index--;
                    }
                }
                if (read_count == -1){
                    if (errno == EINTR){
                        i--; //被中断 重新读取
                        continue;
                    }
                    throw std::runtime_error(std::to_string(fds[i].fd) + " read error - errno: " + std::to_string(errno) ); //发生错误
                }
                if (read_count > 0){
                    buffer[read_count] = '\0';
                    std::cout << "message: " << buffer << std::flush;
                    std::string  message = "get bytes " + std::to_string(read_count) + "\n";
                    auto write_count = write(fds[i].fd, message.c_str() , sizeof(char)*message.size());
                }
            }
        }
    }
    return 0;
}
