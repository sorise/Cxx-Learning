//
// Created by remix on 23-4-23.
//

#ifndef POLL_WRAP_HPP
#define POLL_WRAP_HPP
#include <iostream>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <shared_mutex>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <exception>

int Socket(int domain,int type,int protocol){
    auto socket_fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    if (socket_fd == -1) {
        throw std::runtime_error("create the socket failed!");
    }
    return socket_fd;
}

int Bind(int socket_fd, const struct sockaddr *addr, socklen_t addrlen){
    auto result = bind(socket_fd, addr, addrlen);
    if (result == -1) {
        throw std::runtime_error("bind occur error, please check the data sockaddr!");
    }
    return result;
}

void Listen(int socket_fd, int backlog){
    auto result =  listen(socket_fd, backlog);
    if (result == -1) {
        throw std::runtime_error("listen occur error,the socket failed!");
    }
}

int Accept(int socket_fd, struct sockaddr *addr, socklen_t *addrlen){
    auto new_socket_fd = accept(socket_fd, addr, addrlen);
    if (new_socket_fd == -1) {
        throw std::runtime_error("accept occur error,the socket failed!");
    }
    return new_socket_fd;
}

int Close(int fd){
    auto result = close(fd);
    if (result == -1) {
        throw std::runtime_error("close the socket failed! - errno: "+ std::to_string(errno));
    }
    return result;
}

int initServer(unsigned short port, unsigned short max_connection){
    auto fd = Socket(AF_INET, SOCK_STREAM,0);
    /* 允许地址复用 */
    int opt = 1;
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt)) == -1){
        throw std::runtime_error("set socket error！");
    }
    /* 设置为非阻塞 */
    int newSocketFlag = fcntl(fd, F_GETFL, 0) | O_NONBLOCK;
    fcntl(fd,F_GETFL, newSocketFlag);
    /* 设置发送缓存低潮 */
    int sendLowBufferSize = 2048 ; //2k 字节
    setsockopt(fd, SOL_SOCKET, SO_SNDLOWAT, (const void *) &sendLowBufferSize, sizeof(sendLowBufferSize));
    /* 设置关闭前先发完 */
    linger m_sLinger{1,5};
    setsockopt( fd, SOL_SOCKET, SO_LINGER, (const char*)&m_sLinger, sizeof(struct linger));
    /* 服务器地址 */
    sockaddr_in serverAddress{
            AF_INET,
            htons(port),
            htonl(INADDR_ANY)
    };
    /* 绑定 */
    Bind(fd, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));
    /* 监听 */
    Listen(fd, max_connection);
    std::cout << "start server at 127.0.0.1 running in "<< std::to_string(port) <<":" << "\n";
    return fd; //返回套接字
}
#endif //POLL_WRAP_HPP
