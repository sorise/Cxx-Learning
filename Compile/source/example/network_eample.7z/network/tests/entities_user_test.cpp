#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "user.h"

// Created by remix on 23-3-25.

TEST_CASE("Entities" ,"USER_ADD"){
    user remix(std::string("remix"));
    REQUIRE(100 == remix.calculate(20,30));
    REQUIRE(10 == remix.calculate(2,3));
    REQUIRE(2 == remix.calculate(1,0));
    REQUIRE(0 == remix.calculate(0,0));
}
