#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "toolkits.h"

// Created by remix on 23-3-25.

TEST_CASE("TEST_MY_ADD" ,"ADD"){
    REQUIRE(100 == toolkits::myAdd(20,30));
    REQUIRE(10 == toolkits::myAdd(2,3));
    REQUIRE(2 == toolkits::myAdd(1,0));
    REQUIRE(0 == toolkits::myAdd(0,0));
}

TEST_CASE("TEST_T_ADD" ,"[T Add]"){
    REQUIRE(50 == toolkits::Add(20,30));
    REQUIRE(5 == toolkits::Add(2,3));
    REQUIRE(1 == toolkits::Add(1,0));
    REQUIRE(0 == toolkits::Add(0,0));
}

