//
// Created by remix on 23-3-23.
//

#include "user.h"
#include "toolkits.h"
#include "functional"

std::string  user::getName(){
    return this->_name;
}

int user::calculate(const int& a, const int &b){
    return toolkits::myAdd(std::forward<const int&>(a), std::forward<const int&>(b));
}