//
// Created by remix on 23-3-23.
//

#ifndef NETWORK_USER_H
#define NETWORK_USER_H
#include <string>

class user {
public:
    user(const std::string &name):
    _name(name){};
    user(const user &other):
    _name(other._name){};
    std::string getName();
    int calculate(const int& a, const int &b);
    ~user(){
        printf("user [%s] is over\n", this->_name.c_str());
    };
private:
    std::string _name;
};


#endif //NETWORK_USER_H
