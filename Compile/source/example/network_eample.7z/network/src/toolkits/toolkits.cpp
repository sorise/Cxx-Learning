//
// Created by remix on 23-3-23.
//
#include "toolkits.h"

namespace toolkits{
     int myAdd(const int & a, const int & b){
        return (a + b) * 2;
    }
}