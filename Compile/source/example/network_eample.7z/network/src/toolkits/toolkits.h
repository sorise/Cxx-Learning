//
// Created by remix on 23-3-23.
//

#ifndef __NETWORK_TOOLKITS_H__
#define __NETWORK_TOOLKITS_H__
namespace toolkits{
    template<typename T>
    T Add(const T& one, const T& two){
        return one + two;
    };

    int myAdd(const int & a, const int & b);
}


#endif // !__NETWORK_TOOLKITS_H__
