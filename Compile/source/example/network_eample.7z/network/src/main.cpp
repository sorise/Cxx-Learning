//
// Created by remix on 23-3-23.
//
#include "toolkits.h"
#include "user.h"
#include <iostream>

int main(int args,  char * argv[]){
    std::cout << toolkits::Add<double>(3.14, 6.28) << std::endl;
    std::cout << toolkits::myAdd(5, 6)<<std::endl;
    int age = 12;
    user remix(std::string("remix"));
    std::cout << remix.getName() << " calculate result: " << remix.calculate(5,6) <<"!"<< std::endl;
    return 0;
}